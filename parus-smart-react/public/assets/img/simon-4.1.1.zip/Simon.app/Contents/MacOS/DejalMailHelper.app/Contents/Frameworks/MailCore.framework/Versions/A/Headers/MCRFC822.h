#ifndef MAILCORE_MCRFC822_H

#define MAILCORE_MCRFC822_H

#include <MailCore/MCAttachment.h>
#include <MailCore/MCMessageBuilder.h>
#include <MailCore/MCMessageParser.h>
#include <MailCore/MCMessagePart.h>
#include <MailCore/MCMultipart.h>

#endif
